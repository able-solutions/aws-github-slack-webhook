const AWS = require('aws-sdk');
const moment = require('moment');

exports.handler = function(event, context) {
  
  //const payload = JSON.stringify(event);
  
  //Global Variables
  const branch = (event.ref).split('/')[2];
  let eventType = "Github Event Type Not Known";
  
  //Commit Event Variables
  let commitMessage = "";
  let committer = "";
  let added = [];
  let removed = [];
  let modified = [];
  
  
  if (event.hasOwnProperty('commits')) {
    eventType = "New Commit Detected";
    const commits = event.commits[0];
    commitMessage = commits.message;
    committer = commits.committer.name;
    added = commits.added;
    removed = commits.removed;
    modified = commits.modified;
  }

  console.log({
    "Event": eventType,
    "Branch": branch,
    "CommittedBy": committer,
    "Added": added,
    "Removed": removed,
    "Modified": modified
  });
  
};